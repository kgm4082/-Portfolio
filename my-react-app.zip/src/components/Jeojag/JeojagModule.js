import React from 'react';
import { useState,useEffect } from 'react';
import { Card, Button } from 'react-bootstrap';
import  JeojagCSS from '../../pages/Jeojag/Jeojag.module.css';
import $ from 'jquery';
import MenuTreeList from './MenuTreeList';

// 메뉴 목록
function MenuTree() {

    const [jsonData, setJsonData] = useState(MenuTreeList);
        useEffect(() => {
            const tree = document.querySelector('.tree li:has(ul)');
            tree.classList.add(`${JeojagCSS.parent_li}`);
          },[]);

        // useEffect(() => {
            // $(function () {
                // $('.tree li:has(ul)')
                    // .addClass(`${JeojagCSS.parent_li}`);
                // $('.tree li.parent_li > span').on('click', function (e) {
                //     var children = $(this)
                //         .parent('li.parent_li')
                //         .find(' > ul > li');
                //     if (children.is(':visible')) {
                //         children.hide('fast');
                //     } else {
                //         children.show('fast');
                //     }
                //     e.stopPropagation();
                // });
            // });

    return (
        <div className='d-flex flex-column align-items-stretch flex-shrink-0 bg-white' style={{width: '380px'}}>
            <div className={`${JeojagCSS.tree} tree well`}>
                <ul>
                    {jsonData.map((root) => (
                        <li key={root.id}>
                            <span>
                                <i className='fa-solid fa-folder-open'></i> {root.name}
                            </span>
                            <ul>
                                {root.children.map((child1) => (
                                    <li key={child1.id}>
                                        <span>
                                            <i className='fa-solid fa-file'></i> {child1.name}
                                        </span>
                                        <ul>
                                            {child1.children.map((child2) => (
                                                <li>
                                                    <span>
                                                        <i className='fa-brands fa-linux'></i> {child2.name}
                                                    </span>
                                                </li>
                                            ))}
                                        </ul>
                                    </li>
                                ))}
                            </ul>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    )
}

// 메뉴
function Menu() {

    return (
        <Card>
            <Card.Header style={{backgroundColor: "grey"}}>MENU</Card.Header>
            <Card.Body style={{textAlign: "center"}}>
                <Button style={{marginBottom: "10px" ,width: "100%"}}>네트워크맵 저장(ALT+S)</Button>
                <Button style={{width: "100%"}}>템플릿 불러오기(ALT+T)</Button>
            </Card.Body>
        </Card>
    )
}

function Remocon() {
    return (
        <Card >
            <Card.Header style={{backgroundColor: "GREY"}}>REMOCON</Card.Header>
            <Card.Body style={{display: "flex", flexDirection: "column", alignItems: "center"}}>
                <Card.Text className='text-center'>현재 배율 <br /> 80%</Card.Text>
                <Card.Text>ZOOM</Card.Text>
                <div className='zoom_btn' style={{display: "flex"}}>
                    <Button className='btn-primary'>-</Button>
                    <Button className='btn-danger'>+</Button>
                </div>
                <Button>기본 배율</Button>
            </Card.Body>
        </Card>
    )
}

export { MenuTree, Menu, Remocon };




// import { useState } from 'react';

// const data = [
//   {
//     id: "1",
//     name: "Root",
//     path: "fa-solid fa-folder-open",
//     children: [
//       {
//         id: "1-1",
//         name: "OS",
//         path: "file",
//         children: [
//           {
//             id: "1-1-1",
//             name: "리눅스 (OSquery)",
//             path: "linux"
//           },
//           ...
//         ]
//       },
//       ...
//     ]
//   }
// ];

// function App() {
//   const [jsonData, setJsonData] = useState(data);
  
//   return (
//     <div>
//       {jsonData.map((item) => (
//         <div key={item.id}>
//           <h3>{item.name}</h3>
//           <ul>
//             {item.children.map((childItem) => (
//               <li key={childItem.id}>
//                 <p>{childItem.name}</p>
//                 <p>{childItem.path}</p>
//                 {childItem.children && (
//                   <ul>
//                     {childItem.children.map((grandChildItem) => (
//                       <li key={grandChildItem.id}>
//                         <p>{grandChildItem.name}</p>
//                         <p>{grandChildItem.path}</p>
//                       </li>
//                     ))}
//                   </ul>
//                 )}
//               </li>
//             ))}
//           </ul>
//         </div>
//       ))}
//     </div>
//   );
// }

// export default App;
