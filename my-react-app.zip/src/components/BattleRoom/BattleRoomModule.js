import React from "react";
import { useState } from "react";
import { Card, Button } from "react-bootstrap";
import BattleRoomCSS from "../../pages/BattleRoom/BattleRoom.module.css"; // 배틀룸CSS
import rowComponentList from "./rowComponentList"; // RowComponentList 

function RowComponent() {
    const [comp, setComp] = useState();

    return (
        <div>
        <div id={BattleRoomCSS.rowComponent} className="hide">
            {rowComponentList.map((prop) => (
                <Card className={BattleRoomCSS.rowComponent} key={prop.id}>
                    <Card.Header className={BattleRoomCSS.header}>
                        <p className="name">{prop.name}</p>
                        <p className="difficulty">{prop.difficulty}</p>
                    </Card.Header>
                    <Card.Body className={BattleRoomCSS.body}>
                        <img className={BattleRoomCSS.img} src={prop.img} alt=""/>
                        <Card.Title className={BattleRoomCSS.description}>{prop.description}</Card.Title>
                        <div className={BattleRoomCSS.btns}>
                            <Button className={BattleRoomCSS.btn} /* onClick={() => {setComp(RowComponentDetail(prop.id)); chgcss();}} */>PLAY</Button>
                            <Button className={BattleRoomCSS.btn}>HISTORY</Button>
                        </div>
                    </Card.Body>
                </Card>
            ))}
        </div>
        <div children={comp}></div>
        </div>
    );
}

function chgcss(){
    const hide = document.querySelector(".hide");
    hide.style.display = "none";
}

 function RowComponentDetail(prop) {
    const id = (prop);
    const foundObject = rowComponentList.find((obj)=> obj.id === id);
    console.log(foundObject);
    const childrenValue = foundObject.children;
    return (
        <div id={`${BattleRoomCSS.rowComponentDetail}`}>
            {childrenValue.map((child) => (
                <Card className={BattleRoomCSS.rowComponentDetail} key={child.id}>
                    <Card.Header className={BattleRoomCSS.header}>
                        <p className="name">{child.name}</p>
                        <p className="difficulty">{child.difficulty}</p>
                    </Card.Header>
                    <Card.Body className={BattleRoomCSS.body}>
                        <img className={BattleRoomCSS.img} src={child.img} />
                        <div className="text-cont">
                        <Card.Title className={BattleRoomCSS.description}>{child.description}</Card.Title>
                        <div className={BattleRoomCSS.btns}>
                            <Button className={BattleRoomCSS.btn}>HISTORY</Button>
                            <Button className={BattleRoomCSS.btn}>PLAY</Button>
                        </div>
                        </div>
                    </Card.Body>
                </Card>
            ))}
        </div>
    );
}
export { RowComponent, RowComponentDetail };