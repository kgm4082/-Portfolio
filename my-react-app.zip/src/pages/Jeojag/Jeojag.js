import React from 'react';
import Head from '../../components/Header/Header';
import JeojagCSS from './Jeojag.module.css'
import { MenuTree, Menu, Remocon } from '../../components/Jeojag/JeojagModule';
const Jeojag = () => {
  return (
    <div id='wrap'>
      <Head />
      <div className={JeojagCSS.cdc}>
        <MenuTree />
        <div className={JeojagCSS.eee}>
          <div className={JeojagCSS.menu}>
            <Menu />
            <Remocon />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Jeojag;