import React from 'react';
import Head from '../../components/Header/Header'; // 헤더
import {RowComponent} from '../../components/BattleRoom/BattleRoomModule'; // 로우컴포넌트 모듈
import BattleRoomCSS from './BattleRoom.module.css'; // 배틀룸CSS

const BattleRoom = () => {
  return (
    <div id='wrap'>
      <Head />
      <div className={BattleRoomCSS.title}>Battle Rooms</div>
      <div className={BattleRoomCSS.cont}>
      <RowComponent />
      </div>
    </div>
  );
};

export default BattleRoom;