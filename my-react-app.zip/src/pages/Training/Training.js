import React from 'react';
import Head from '../../components/Header/Header';

const Training = () => {
  return (
    <div id='wrap'>
      <Head />
      <div className='sbs'>
        <div className='d-flex flex-column align-items-stretch flex-shrink-0 bg-white' style={{width: '280px'}}>
          <ul>
            <li><img /></li>
            <li><img /></li>
            <li><img /></li>
            <li><img /></li>
            <li><img /></li>
            <li><img /></li>
            <li><img /></li>
          </ul>
        </div>
        <div className='eee'>
          
        </div>
      </div>
    </div>
  );
};

export default Training;