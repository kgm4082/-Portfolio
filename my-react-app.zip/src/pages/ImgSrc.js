
const isrc = {
    
    // 이미지경로
    logo:'/assets/img/jiinLogo.png',
};

export default isrc;